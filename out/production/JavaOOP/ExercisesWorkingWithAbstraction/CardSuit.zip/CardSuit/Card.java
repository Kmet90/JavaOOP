package ExercisesWorkingWithAbstraction.CardSuit;

public enum Card {
    CLUBS,
    DIAMONDS,
    HEARTS,
    SPADES
}
